Monitorica Free Font, 09/09/2014, v.1.0, download @
http://www.iphostmonitor.com/monitorica-font.html

Spread under Attribution-ShareAlike 4.0 International
license http://creativecommons.org/licenses/by-sa/4.0/